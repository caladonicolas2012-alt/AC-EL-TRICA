# AC-Elétrica — como colocar o site no ar

## 1. Criar o banco (grátis)
1. Crie uma conta em supabase.com e um **New project** (guarde a senha do banco).
2. Menu **SQL Editor** → cole o conteúdo de `supabase.sql` → **Run**.
3. Menu **Authentication → Users → Add user → Create new user**: coloque o SEU e-mail e uma senha forte, marcando "Auto Confirm User". Esse é o único acesso administrativo.
4. Menu **Authentication → Sign In / Providers**: desative **"Allow new users to sign up"** (impede que outras pessoas criem contas).
5. Menu **Project Settings → API**: copie a **Project URL** e a chave **anon public** (NUNCA use a `service_role`).

## 2. Configurar o site
Abra `index.html` em um editor de texto e troque, perto do fim do arquivo:
- `COLE_AQUI_A_URL_DO_PROJETO` → sua Project URL
- `COLE_AQUI_A_ANON_KEY` → sua chave anon public

## 3. Publicar
Use Netlify, Vercel ou Cloudflare Pages: crie a conta, arraste a pasta `ac-eletrica` para publicar. Você recebe um link público.

## 4. Usar
- Rodapé → **Área administrativa** → entre com o e-mail e a senha do passo 3.
- Aparece a faixa dourada: envie várias fotos, edite (✎), exclua (🗑), aprove ou exclua avaliações, altere o WhatsApp.
- Visitantes enviam avaliações sem login; elas só aparecem depois que você aprovar.
- Fotos ficam no Supabase Storage (plano grátis: 1 GB; a capacidade depende do plano).
