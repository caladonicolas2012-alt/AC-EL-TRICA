-- Cole TUDO isto no Supabase > SQL Editor > Run
create table if not exists photos  (id text primary key, data jsonb not null);
create table if not exists reviews (id text primary key, data jsonb not null);
create table if not exists config  (id text primary key, data jsonb not null);
alter table photos enable row level security;
alter table reviews enable row level security;
alter table config enable row level security;

-- Fotos e configurações: todos leem, só o administrador (logado) altera
create policy "fotos leitura" on photos for select using (true);
create policy "fotos admin" on photos for all to authenticated using (true) with check (true);
create policy "config leitura" on config for select using (true);
create policy "config admin" on config for all to authenticated using (true) with check (true);

-- Avaliações: visitantes só veem as aprovadas e só podem enviar novas PENDENTES
create policy "aval publicas" on reviews for select using (data->>'ok' = 'true');
create policy "aval enviar" on reviews for insert to anon, authenticated
  with check (data->>'ok' = 'false' and (data->>'n')::int between 1 and 5
              and length(data->>'text') between 5 and 500 and length(data->>'name') between 1 and 60);
create policy "aval admin" on reviews for all to authenticated using (true) with check (true);

-- Armazenamento das fotos
insert into storage.buckets (id, name, public) values ('fotos','fotos',true) on conflict do nothing;
create policy "fotos publicas" on storage.objects for select using (bucket_id = 'fotos');
create policy "fotos upload admin" on storage.objects for insert to authenticated with check (bucket_id = 'fotos');
create policy "fotos delete admin" on storage.objects for delete to authenticated using (bucket_id = 'fotos');
